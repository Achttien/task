param(
  [string]$InstallDir = "$env:USERPROFILE\gcalsheet-agent"
)

$ErrorActionPreference = 'Stop'

Write-Host "Installing to $InstallDir" -ForegroundColor Cyan

# Create virtual env
python -m venv "$InstallDir\venv"

# Activate and install
& "$InstallDir\venv\Scripts\python.exe" -m pip install --upgrade pip
& "$InstallDir\venv\Scripts\python.exe" -m pip install --no-warn-script-location --upgrade "pipx"

# Install package editable from local app folder
& "$InstallDir\venv\Scripts\pip.exe" install --no-deps --no-index --find-links "$PSScriptRoot\wheelhouse" -r "$PSScriptRoot\requirements.txt"
& "$InstallDir\venv\Scripts\pip.exe" install --no-deps --no-index --find-links "$PSScriptRoot\wheelhouse" "$PSScriptRoot\app"

# Create launch script
$newLine = [Environment]::NewLine
$bat = @()
$bat += "@echo off"
$bat += "call \"$InstallDir\venv\Scripts\activate.bat\""
$bat += "gcalsheet-agent %*"
[IO.File]::WriteAllText("$InstallDir\gcalsheet-agent.cmd", ($bat -join $newLine))

Write-Host "Installation complete. Add $InstallDir to PATH or run: $InstallDir\gcalsheet-agent.cmd" -ForegroundColor Green
